﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace WinningTickets
{
    class Program
    {
        static void Main(string[] args)
        {
            var input = Console.ReadLine().Split(new char[] { ' ', ','}, StringSplitOptions.RemoveEmptyEntries).ToArray();

            var match = @"(@|#|\$|\^){6,12}(\w+|)\1{6,12}";
            
            Regex regex = new Regex(match);
            
            for (int i = 0; i < input.Length; i++)
            {
                var counterA = 0;
                var counterDies = 0;
                var counterDolar = 0;
                var counterCovka = 0;

                if (input[i].Length == 20)
                {

                    for (int e = 0; e < input[i].Length; e++)
                    {
                        if (input[i][e] == '@')
                        {
                            counterA++;
                        }
                        else if (input[i][e] == '#')
                        {
                            counterDies++;
                        }
                        else if (input[i][e] == '$')
                        {
                            counterDolar++;
                        }
                        else if (input[i][e] == '^')
                        {
                            counterCovka++;
                        }

                    }
                }

                var currency = "";

                if (counterA >= 12)
                {
                    currency = "@";
                }
                else if (counterDies >= 12)
                {
                    currency = "#";
                }
                else if (counterDolar >= 12)
                {
                    currency = "$";
                }
                else if (counterCovka >= 12)
                {
                    currency = "^";
                }


                var isMatch = regex.IsMatch(input[i]);

                if (input[i].Length < 20)
                {
                    Console.WriteLine("invalid ticket");
                }
                else if (counterA >= 12 && counterA < 20 && isMatch)
                {
                    Console.WriteLine($@"ticket ""{input[i]}"" - {counterA / 2}{currency}");
                }
                else if (counterCovka >= 12 && counterCovka < 20 && isMatch)
                {
                    Console.WriteLine($@"ticket ""{input[i]}"" - {counterCovka / 2}{currency}");
                }
                else if (counterDies >= 12 && counterDies < 20 && isMatch)
                {
                    Console.WriteLine($@"ticket ""{input[i]}"" - {counterDies / 2}{currency}");
                }
                else if (counterDolar >= 12 && counterDolar < 20 && isMatch)
                {
                    Console.WriteLine($@"ticket ""{input[i]}"" - {counterDolar / 2}{currency}");
                }
                else if (counterA == 20 || counterCovka == 20 || counterDies == 20 || counterDolar == 20)
                {
                    Console.WriteLine($@"ticket ""{input[i]}"" - {counterDolar / 2}{currency} Jackpot!");
                }
                else
                {
                    Console.WriteLine($@"ticket ""{input[i]}"" - no match");
                }
            }

        }
    }
}
