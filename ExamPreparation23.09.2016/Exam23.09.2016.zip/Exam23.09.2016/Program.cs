﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exam23._09._2016
{
    class Program
    {
        static void Main(string[] args)
        {
            var a = -1;
            var b = 1 - a;

            Console.WriteLine(b);

        }
    }
}
